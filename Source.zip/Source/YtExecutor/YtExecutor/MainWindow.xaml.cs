﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EasyExploits;

namespace YtExecutor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Module api = new Module();
        public MainWindow()
        {
            InitializeComponent();
            Functions.PopulateListBox(this.Viewer, "./Scripts", "*.txt");
            Functions.PopulateListBox(this.Viewer, "./Scripts", "*.lua");
        }

        private void MainWindow1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
         DragMove();
        }

        private void clearbtn_Click(object sender, RoutedEventArgs e)
        {
            Editor.Clear();
        }

        private void openbtn_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
                Editor.Text = File.ReadAllText(openFileDialog.FileName);
        }

        private void savebtn_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Txt Files (*.txt)|*.txt|Best file format (*.aer)|*.aer|Lua Files (*.lua)|*.lua|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog() == true)
                File.WriteAllText(saveFileDialog.FileName, Editor.Text);
        }

        private void Viewer_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            bool flag = this.Viewer.SelectedIndex != -1;
            if (flag)
            {
                Editor.Text = File.ReadAllText("scripts\\" + this.Viewer.SelectedItem.ToString());
            }
        }

        private void exitbtn_Click(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void minimizebtn_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void executebtn_Click(object sender, RoutedEventArgs e)
        {
            api.ExecuteScript(Editor.Text);
        }

        private void attachbtn_Click(object sender, RoutedEventArgs e)
        {
            api.LaunchExploit();
        }
    }
}
